-- Esquema local de desarrollo para RPV Construcciones.
-- Reconstruido desde la API guardar-ubicacion.php; reemplazar por un export de
-- cPanel antes de una réplica exacta de producción.

CREATE DATABASE IF NOT EXISTS rpvconst_DataMain_dev
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE rpvconst_DataMain_dev;

CREATE TABLE IF NOT EXISTS ubicaciones_chat (
  id_ubicacion BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_conversacion VARCHAR(100) NULL,
  comuna VARCHAR(100) NULL,
  provincia VARCHAR(100) NULL,
  region VARCHAR(150) NULL,
  pais VARCHAR(100) NOT NULL DEFAULT 'Chile',
  latitud DECIMAL(10,7) NOT NULL,
  longitud DECIMAL(10,7) NOT NULL,
  precision_metros DECIMAL(12,2) NULL,
  url_google_maps VARCHAR(500) NOT NULL,
  fuente_ubicacion ENUM('navegador', 'manual') NOT NULL DEFAULT 'navegador',
  fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_ubicacion),
  KEY idx_ubicaciones_chat_conversacion_fecha (id_conversacion, fecha_registro),
  KEY idx_ubicaciones_chat_fecha (fecha_registro)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS testimonios (
  id_testimonio BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre_publico VARCHAR(80) NOT NULL,
  correo_privado VARCHAR(254) NULL,
  ciudad VARCHAR(80) NULL,
  empresa_pyme VARCHAR(120) NULL,
  categoria VARCHAR(30) NOT NULL DEFAULT 'General',
  calificacion TINYINT UNSIGNED NULL,
  comentario TEXT NOT NULL,
  consentimiento_publicacion TINYINT(1) NOT NULL DEFAULT 0,
  estado ENUM('borrador', 'publicado') NOT NULL DEFAULT 'borrador',
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  publicado_en TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id_testimonio),
  KEY idx_testimonios_estado_fecha (estado, publicado_en)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Conserva los testimonios existentes al actualizar una base ya inicializada.
ALTER TABLE testimonios
  ADD COLUMN IF NOT EXISTS empresa_pyme VARCHAR(120) NULL AFTER ciudad;

ALTER TABLE testimonios
  ADD COLUMN IF NOT EXISTS correo_privado VARCHAR(254) NULL AFTER nombre_publico;

-- Opiniones de producto recibidas desde el sitio local de desarrollo.
CREATE TABLE IF NOT EXISTS opiniones_productos (
  id_opinion BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre_publico VARCHAR(80) NOT NULL,
  correo_privado VARCHAR(254) NOT NULL,
  producto VARCHAR(40) NOT NULL,
  calificacion TINYINT UNSIGNED NOT NULL,
  comentario VARCHAR(1200) NOT NULL,
  consentimiento_publicacion TINYINT(1) NOT NULL DEFAULT 0,
  estado ENUM('pendiente', 'aprobado', 'rechazado') NOT NULL DEFAULT 'pendiente',
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revisado_en TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id_opinion),
  KEY idx_opiniones_estado_fecha (estado, creado_en),
  KEY idx_opiniones_producto_estado (producto, estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
