<?php
declare(strict_types=1);
$adminHome = '/precios.php';
require __DIR__ . '/acceso.php';
require dirname(__DIR__) . '/modulos/catalogo/Catalogo.php';
$catalogo = new \RPV\Catalogo\Catalogo();
$error = '';
$draftId = '';
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) { http_response_code(403); exit('La sesión caducó. Recarga la página.'); }
        if (($_POST['action'] ?? '') !== 'save_product') throw new InvalidArgumentException('Acción no válida.');
        $draftId = is_string($_POST['product_id'] ?? null) ? $_POST['product_id'] : '';
        $revision = is_string($_POST['revision'] ?? null) ? $_POST['revision'] : '';
        $catalogo->guardar($draftId, $_POST, $revision);
        notice('Producto actualizado. Sus valores y condiciones ya están sincronizados en las páginas de desarrollo, ambos asistentes y el archivo de conocimiento.');
        go('/precios.php#' . rawurlencode($draftId));
    }
} catch (InvalidArgumentException | RuntimeException $e) { $error = $e->getMessage(); }
try { $data = $catalogo->leer(); }
catch (Throwable $e) { error_log('RPV catálogo: ' . $e->getMessage()); http_response_code(503); exit('No se pudo abrir el catálogo. Revisa la configuración local.'); }
$flash = $_SESSION['notice'] ?? null;
unset($_SESSION['notice']);
$labels = ['rendimiento'=>'Referencia técnica o rendimiento', 'incluye'=>'Qué incluye', 'condiciones'=>'Condiciones comerciales', 'instalacion'=>'Instalación', 'despacho'=>'Despacho', 'garantia'=>'Garantía'];
?>
<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Administrar precios y condiciones · RPV Construcciones</title><link rel="stylesheet" href="/assets/admin.css"><link rel="stylesheet" href="/assets/precios.css"><script src="/assets/precios.js" defer></script></head>
<body><a class="skip" href="#contenido">Ir a los productos</a>
<header class="topbar"><a class="brand" href="/precios.php"><span class="brand-mark" aria-hidden="true">RPV</span><span>RPV Construcciones<small>Precios y condiciones</small></span></a><nav class="top-actions" aria-label="Administración"><a class="site-link" href="/">Testimonios</a><a class="site-link" href="http://localhost:8000/" target="_blank" rel="noopener">Ver sitio</a><form method="post" action="/precios.php"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="logout"><button class="logout" type="submit">Cerrar sesión</button></form></nav></header>
<main class="prices-shell" id="contenido"><div class="prices-intro"><span class="eyebrow">CATÁLOGO COMERCIAL · DESARROLLO</span><h1>Un solo precio, en todo el sitio.</h1><p>Administra los valores y condiciones por producto. Al guardar se actualizan sus páginas, las respuestas de ambos asistentes y el archivo de conocimiento.</p><p class="scope-note">Los cambios se aplican al sitio de desarrollo. La publicación al sitio público se realiza por el flujo habitual de producción.</p></div>
<?php if ($flash): ?><div class="alert" role="status"><?= h($flash['message']) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error" role="alert" tabindex="-1" id="save-error"><?= h($error) ?> Los demás productos conservan sus datos.</div><?php endif; ?>
<nav class="product-index" aria-label="Ir a un producto"><?php foreach ($data['productos'] as $p): ?><a href="#<?= h($p['id']) ?>"><?= h($p['nombre']) ?></a><?php endforeach; ?></nav>
<p class="initial-note">Los valores iniciales son referencias del contenido existente. Revisa cada producto y confirma sus condiciones al guardar. Si no hay un monto confirmado, selecciona «A consultar».</p>
<div class="products-editor">
<?php foreach ($data['productos'] as $stored): $p = $stored; if ($error && $draftId === $p['id']) { foreach (array_merge(['modo_precio','precio_clp','vigente_hasta'], array_keys($labels)) as $key) if (isset($_POST[$key]) && is_string($_POST[$key])) $p[$key] = $_POST[$key]; } ?>
<section class="product-editor" id="<?= h($p['id']) ?>" aria-labelledby="title-<?= h($p['id']) ?>"><div class="product-heading"><div><span class="product-kind"><?= h(ucfirst($p['categoria'])) ?></span><h2 id="title-<?= h($p['id']) ?>"><?= h($p['nombre']) ?></h2></div><span class="approval-status"><?= $stored['aprobado'] ? 'Revisado en el panel' : 'Referencia inicial' ?></span></div><p class="product-reference">Identificador: <code><?= h($p['id']) ?></code></p>
<form method="post" action="/precios.php#<?= h($p['id']) ?>" class="price-form"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="save_product"><input type="hidden" name="product_id" value="<?= h($p['id']) ?>"><input type="hidden" name="revision" value="<?= h($data['revision']) ?>">
<div class="price-row"><label>Estado del precio<select name="modo_precio"><option value="referencial" <?= $p['modo_precio']==='referencial'?'selected':'' ?>>Referencial</option><option value="vigente" <?= $p['modo_precio']==='vigente'?'selected':'' ?>>Vigente</option><option value="consultar" <?= $p['modo_precio']==='consultar'?'selected':'' ?>>A consultar</option></select></label><label>Precio en pesos chilenos<input type="number" name="precio_clp" min="1" max="999999999" step="1" inputmode="numeric" value="<?= h((string)($p['precio_clp'] ?? '')) ?>" aria-describedby="price-help-<?= h($p['id']) ?>"><small id="price-help-<?= h($p['id']) ?>">Sin puntos ni símbolo $. Ejemplo: 1150000.</small></label><label><span>Vigente hasta <span class="optional">(opcional)</span></span><input type="date" name="vigente_hasta" value="<?= h($p['vigente_hasta']) ?>"><small>Al vencer, se mostrará «Precio a consultar».</small></label></div>
<div class="commercial-fields"><?php foreach ($labels as $key=>$label): ?><label><?= h($label) ?><textarea name="<?= h($key) ?>" rows="3" maxlength="1200" required><?= h($p[$key]) ?></textarea></label><?php endforeach; ?></div>
<div class="save-product"><label class="approve"><input type="checkbox" name="aprobar" value="1" required><span>Confirmo estos valores y condiciones comerciales para actualizar el sitio de desarrollo.</span></label><button class="primary" type="submit">Guardar y sincronizar producto</button></div>
<?php if ($stored['actualizado_el']): ?><p class="updated">Última revisión: <?= h((new DateTimeImmutable($stored['actualizado_el']))->setTimezone(new DateTimeZone('America/Santiago'))->format('d-m-Y H:i')) ?> · hora de Chile</p><?php endif; ?>
</form></section><?php endforeach; ?></div></main></body></html>
