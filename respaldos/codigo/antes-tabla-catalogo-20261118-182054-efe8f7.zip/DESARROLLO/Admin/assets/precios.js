(() => {
  'use strict';
  document.querySelectorAll('.price-form').forEach(form => {
    const mode = form.elements.modo_precio, price = form.elements.precio_clp;
    const update = () => { price.disabled = mode.value === 'consultar'; price.required = !price.disabled; };
    mode.addEventListener('change', update); update();
  });
  const error = document.getElementById('save-error');
  if (error) error.focus();
})();