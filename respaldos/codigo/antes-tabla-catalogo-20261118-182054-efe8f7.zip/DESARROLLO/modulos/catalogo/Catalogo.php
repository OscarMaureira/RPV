<?php
declare(strict_types=1);

namespace RPV\Catalogo;

final class Catalogo
{
    public const IDS = ['caldera-tipo-a', 'caldera-tipo-b', 'caldera-tipo-c', 'tinaja-4-personas', 'tinaja-7-personas', 'estufa-pellet'];
    public const TEXTOS = ['rendimiento', 'incluye', 'condiciones', 'instalacion', 'despacho', 'garantia'];
    private string $root;
    public function __construct(?string $root = null) { $this->root = $root ?? dirname(__DIR__, 2); }
    private function source(): string { return $this->root . '/catalogo/productos.json'; }
    public function leer(): array {
        $data = json_decode((string) file_get_contents($this->source()), true, 512, JSON_THROW_ON_ERROR);
        if (($data['schema_version'] ?? null) !== 1 || !is_string($data['revision'] ?? null) || count($data['productos'] ?? []) !== count(self::IDS)) throw new \RuntimeException('Catálogo inválido.');
        $ids = array_column($data['productos'], 'id');
        if ($ids !== self::IDS) throw new \RuntimeException('Los identificadores del catálogo no son válidos.');
        foreach ($data['productos'] as $p) $this->validar($p);
        return $data;
    }
    private function texto(mixed $value, int $max = 1200): string {
        if (!is_string($value) || preg_match('//u', $value) !== 1) throw new \InvalidArgumentException('Ingresa texto válido.');
        $value = trim((string) preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $value));
        if (strlen($value) > $max * 4 || (function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value)) > $max) throw new \InvalidArgumentException("El texto supera $max caracteres.");
        return $value;
    }
    private function validar(array $p): void {
        if (!in_array($p['id'] ?? '', self::IDS, true) || !in_array($p['categoria'] ?? '', ['calderas','tinajas','estufas'], true)) throw new \InvalidArgumentException('Producto inválido.');
        if (!in_array($p['modo_precio'] ?? '', ['referencial','vigente','consultar'], true)) throw new \InvalidArgumentException('Selecciona un estado de precio válido.');
        $price = $p['precio_clp'] ?? null;
        if ($p['modo_precio'] === 'consultar') { if ($price !== null) throw new \InvalidArgumentException('Un precio a consultar debe quedar sin monto.'); }
        elseif (!is_int($price) || $price < 1 || $price > 999999999) throw new \InvalidArgumentException('El precio debe ser un entero entre 1 y 999.999.999 pesos.');
        $until = $p['vigente_hasta'] ?? '';
        if (!is_string($until) || ($until !== '' && (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $until) || !checkdate((int)substr($until,5,2),(int)substr($until,8,2),(int)substr($until,0,4))))) throw new \InvalidArgumentException('La fecha de vigencia no es válida.');
        foreach (array_merge(['nombre'], self::TEXTOS) as $key) {
            if (is_string($p[$key] ?? null) && preg_match('/\$\s*\d|\b\d[\d.,]*\s*(?:CLP|pesos)\b/iu', $p[$key])) throw new \InvalidArgumentException('Usa el campo Precio para los montos; no repitas valores en los textos comerciales.');
            if ($this->texto($p[$key] ?? null) === '') throw new \InvalidArgumentException('Completa todos los textos comerciales. Puedes indicar que un dato está sujeto a confirmación.');
        }
    }
    public function guardar(string $id, array $input, string $revision): array {
        return $this->conBloqueo(function () use ($id, $input, $revision) {
            $data = $this->leer();
            if (!hash_equals($data['revision'], $revision)) throw new \RuntimeException('El catálogo cambió en otra ventana. Recarga antes de guardar para no sobrescribir esos cambios.');
            $index = array_search($id, self::IDS, true);
            if ($index === false) throw new \InvalidArgumentException('El producto no existe.');
            if (($input['aprobar'] ?? '') !== '1') throw new \InvalidArgumentException('Confirma los datos comerciales antes de guardar.');
            $p = $data['productos'][$index];
            $p['modo_precio'] = $this->texto($input['modo_precio'] ?? '', 20);
            $raw = $input['precio_clp'] ?? '';
            if (!is_string($raw)) throw new \InvalidArgumentException('Precio inválido.');
            if ($p['modo_precio'] !== 'consultar' && !preg_match('/^[1-9][0-9]{0,8}$/D', $raw)) throw new \InvalidArgumentException('Escribe el precio en pesos enteros, sin puntos ni símbolos.');
            $p['precio_clp'] = $p['modo_precio'] === 'consultar' ? null : (int) $raw;
            $p['vigente_hasta'] = $this->texto($input['vigente_hasta'] ?? '', 10);
            foreach (self::TEXTOS as $key) $p[$key] = $this->texto($input[$key] ?? '');
            $p['aprobado'] = true;
            $p['actualizado_el'] = date(DATE_ATOM);
            $this->validar($p);
            $data['productos'][$index] = $p;
            $data['revision'] = bin2hex(random_bytes(16));
            $data['actualizado_el'] = date(DATE_ATOM);
            $targets = $this->artefactos($data);
            // El JSON público contiene también el Markdown: cada consulta del asistente lee una sola revisión.
            $targets = [$this->source() => $this->json($data)] + $targets;
            $history = $this->root . '/catalogo/historial';
            if (!is_dir($history) && !mkdir($history, 0770, true)) throw new \RuntimeException('No se pudo crear el historial.');
            $old = (string) file_get_contents($this->source());
            $archive = $history . '/' . date('Ymd-His') . '-' . bin2hex(random_bytes(6)) . '.json';
            if (file_put_contents($archive, $old, LOCK_EX) !== strlen($old)) throw new \RuntimeException('No se pudo respaldar la revisión anterior.');
            $this->publicar($targets);
            return $data;
        });
    }
    private function conBloqueo(callable $fn): mixed {
        $handle = fopen($this->root . '/catalogo/.catalogo.lock', 'c');
        if (!$handle || !flock($handle, LOCK_EX)) throw new \RuntimeException('No se pudo bloquear el catálogo.');
        try { return $fn(); } finally { flock($handle, LOCK_UN); fclose($handle); }
    }
    private function json(array $data): string { return json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n"; }
    public function precioTexto(array $p): string {
        if ($p['modo_precio'] === 'consultar' || ($p['vigente_hasta'] !== '' && $p['vigente_hasta'] < (new \DateTimeImmutable('now', new \DateTimeZone('America/Santiago')))->format('Y-m-d'))) return 'Precio a consultar';
        return '$' . number_format($p['precio_clp'], 0, ',', '.') . ' CLP' . ($p['modo_precio'] === 'referencial' ? ' · referencial' : '');
    }
    private function publico(array $p): array {
        $p['precio_texto'] = $this->precioTexto($p);
        $p['vigencia_texto'] = $p['vigente_hasta'] === '' ? 'Confirma precio y disponibilidad al cotizar.' : 'Vigencia informada hasta ' . $p['vigente_hasta'] . '. Confirma disponibilidad al cotizar.';
        $p['respuesta'] = $p['nombre'] . ': ' . $p['precio_texto'] . '. ' . $p['rendimiento'] . ' Incluye: ' . $p['incluye'] . ' Condiciones: ' . $p['condiciones'] . ' ' . $p['vigencia_texto'];
        if ($p['precio_texto'] === 'Precio a consultar') $p['precio_clp'] = null;
        return $p;
    }
    public function artefactos(array $data): array {
        $products = array_map(fn($p) => $this->publico($p), $data['productos']);
        $map = array_column($products, null, 'id');
        $base = (string) file_get_contents($this->root . '/modulos/catalogo/conocimiento-base.md');
        if (preg_match('/\$\s*\d|\bEquipo\s+[123]\b/iu', $base)) throw new \RuntimeException('La base editorial contiene precios o modelos retirados. Usa el catálogo comercial.');
        $md = "# RPV Construcciones — Base de conocimiento del asistente\n\n> Generado desde el catálogo comercial. Revisión: " . $data['revision'] . ". Administrar desde el panel de precios; no editar este archivo generado.\n\n";
        foreach (['calderas'=>'calderas','tinajas'=>'tinajas','estufas'=>'estufas a pellets'] as $category=>$name) {
            $md .= "## ¿Cuáles son los precios de las $name?\n";
            foreach ($products as $p) if ($p['categoria'] === $category) $md .= $p['respuesta'] . "\n";
            $md .= "\n";
        }
        foreach ($products as $p) {
            $md .= '## ¿Cuánto cuesta ' . $p['nombre'] . "?\n" . $p['respuesta'] . "\n\n";
            foreach (self::TEXTOS as $key) $md .= '## ' . ucfirst($key) . ' — ' . $p['nombre'] . "\n" . $p[$key] . "\n\n";
        }
        $md .= "## ¿A qué tipo corresponden los antiguos equipos numerados?\nLas referencias antiguas no tienen una equivalencia aprobada. Indica caldera tipo A, B o C, o consulta con el equipo por WhatsApp.\n\n" . trim($base) . "\n";
        $targets = [];
        foreach (['index.html','calderas/index.html','tinajas/index.html','estufas-a-pellets/index.html'] as $file) {
            $filename = $this->root . '/Web/' . $file;
            $html = (string) file_get_contents($filename);
            $html = preg_replace_callback('~(<(span|p|h3|strong)\b[^>]*data-catalog-product="([^"]+)"[^>]*data-catalog-field="([^"]+)"[^>]*>)[^<]*(</\2>)~u', function($m) use ($map) {
                if (!isset($map[$m[3]])) throw new \RuntimeException('Identificador desconocido en el sitio: ' . $m[3]);
                $value = $m[4] === 'precio' ? $map[$m[3]]['precio_texto'] : ($map[$m[3]][$m[4]] ?? null);
                if (!is_string($value)) throw new \RuntimeException('Campo desconocido en el sitio: ' . $m[4]);
                return $m[1] . htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . $m[5];
            }, $html);
            if ($html === null) throw new \RuntimeException('No se pudo sincronizar ' . $file);
            $targets[$filename] = $html;
        }
        $targets[$this->root . '/Web/assets/data/conocimiento-rpv.md'] = $md;
        $targets[$this->root . '/Web/assets/data/catalogo-rpv.json'] = $this->json(['schema_version'=>1,'revision'=>$data['revision'],'actualizado_el'=>$data['actualizado_el'],'productos'=>$products,'conocimiento'=>$md]);
        return $targets;
    }
    public function sincronizar(bool $check = false): void {
        $this->conBloqueo(function () use ($check) {
            $targets = $this->artefactos($this->leer());
            if ($check) {
                foreach ($targets as $file=>$content) if (!is_file($file) || file_get_contents($file) !== $content) throw new \RuntimeException('Catálogo sin sincronizar: ' . basename($file));
            } else $this->publicar($targets);
        });
    }
    private function reemplazar(string $file, string $content): void {
        $temp = tempnam(dirname($file), '.rpv-catalogo-');
        if ($temp === false) throw new \RuntimeException('No se pudo preparar la sincronización.');
        try {
            if (file_put_contents($temp, $content, LOCK_EX) !== strlen($content) || !@rename($temp, $file)) throw new \RuntimeException('No se pudo actualizar ' . basename($file));
        } finally { if (is_file($temp)) unlink($temp); }
    }
    private function publicar(array $targets): void {
        $before = [];
        try {
            foreach ($targets as $file=>$content) {
                if (is_file($file) && file_get_contents($file) === $content) continue;
                $before[$file] = is_file($file) ? file_get_contents($file) : null;
                $this->reemplazar($file, $content);
            }
        } catch (\Throwable $e) {
            foreach (array_reverse($before, true) as $file=>$old) {
                try { if ($old === null) { if (is_file($file)) unlink($file); } else $this->reemplazar($file, $old); }
                catch (\Throwable $rollback) { error_log('RPV catálogo: recuperación incompleta: ' . basename($file)); }
            }
            throw new \RuntimeException('No se guardó el cambio. Revisa permisos de escritura del catálogo y sus archivos generados.', 0, $e);
        }
    }
}
